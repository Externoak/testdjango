import os
import os.path
os.system("apt-get install gcc python-dev python-pip")
os.system("wget https://bootstrap.pypa.io/get-pip.py")
os.system("\n python get-pip.py")
os.system("pip install speedtest-cli")
os.system("pip install netifaces")
os.system("pip install python-nmap")
os.system("pip install psutil")
