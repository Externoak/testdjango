# Python-Scripts-SYSAdmin

(Work in progress)

How to use:
		
       git clone https://github.com/Externoak/Python-Scripts-SYSAdmin.git
			 
			 python main.py
			 
			 INSTALL Dependencies if it's your first time. (Option "9")
			 
Just navitage the menu with the option you need.

Current Scripts.

		 Nmap. It will scan all open ports in your current computer and scan all other computers currently in your network.
				
		 Speedtest. Will connect to speedtest and test your network speed. Results will be prompt to terminal.
				
		 Pingcheck. Will ping all IP's at specified network checking who's active. 
				
		 Webstatus. Will check specified domain and check if it's currently working.
		 
		 CheckInterface. Will check specified interface and print to terminal main info.
